#--------------------------------------------------------------------------
#
# simple garch(1,1) model:
#
# eps_t = sig_t * z_t
# z_t ~iid N(0,1)
# sig^2_t^2 = omega + alpha * eps^2_t-1 + beta * sig^2_t-1
#
# for simulation, eps_0 and sig_0 must be given.
# default to eps_0 ~ N(0, tau) and sig^2_0 = tau,
# where tau = omega/(1-alpha-beta).
#
# for inference, assume that eps^2_0 = sig^2_0 = mean(eps^2)
#
#--------------------------------------------------------------------------

#' Simulate data from a GARCH(1,1) model.
#'
#' @param nobs Total number of observations.
#' @param nts Number of time series to generate.
#' @param omega,alpha,beta GARCH(1,1) parameters (see Details).
#' @param eps0,sig0 Initial values, i.e., at the time point immediately before the first observation (see Details).
#' @param z Optional \code{nobs x nts} matrix of innovations.  Defaults to iid \code{N(0,1)}.
#' @param eps.only If \code{TRUE} outputs only the asset series.  Otherwise also outputs the volatilities and innovations.
#' @param init.out If \code{TRUE} returns \code{eps0} and \code{sig0}.
#' @return
#' \itemize{
#'   \item For a single time series, a vector \code{eps} of length \code{nobs} or \code{nobs x 3} matrix \code{cbind(eps, sig, z)}.
#'   \item For multiple series, a \code{nobs x nts} matrix \code{eps} or a list with elements \code{eps}, \code{sig}, and \code{z}.
#'   \item If \code{init.out == TRUE}, a list with elements \code{sim} containing the previous result and \code{init} containing a \code{nts x 2} matrix of starting values.
#' }
#' @details The GARCH(1,1) model is
#' \preformatted{
#' eps_t = sig_t * z_t
#' sig^2_t^2 = omega + alpha * eps^2_t-1 + beta * sig^2_t-1,
#' }
#' where \code{z_t} are iid innovations with mean 0 and variance 1.  By default these are assumed to be normal but can be arbitrarily specified through the argument \code{z}.
#'
#' The parameters and initial values can be scalars or of length \code{nts}.  The default initial values are \code{sig0 = sqrt(tau)} and \code{eps0 = rnorm(nts, 0, sqrt(tau))}, where \code{tau = omega/(1-alpha-beta)} is the variance of the GARCH(1,1) stationary distribution.
#' @export
garch.sim <- function(nobs, nts = 1, omega, alpha, beta, eps0, sig0,
                      z, eps.only = TRUE, init.out = FALSE) {
  # innovations
  if(missing(z)) {
    # when "vectorizing" in R always try to do along columns
    # at the expense of transposing before and after calculation
    z <- matrix(rnorm(nobs*nts),nts, nobs)
  } else {
    # check if z is of right size
    # good habit to do this in separate function
    # for improved readability and reusability
    z <- .format_z(z, nobs, nts)
  }
  # memory allocation
  eps <- matrix(NA, nts, nobs+1)
  sig2 <- matrix(NA, nts, nobs+1)
  # default initial values
  if(missing(sig0)) sig0 <- sqrt(omega/(1-alpha-beta))
  if(missing(eps0)) eps0 <- rnorm(nts, sd = sig0)
  #z <- cbind(eps0/sig0, z) # first innovation determined by initial values
  eps[,1] <- eps0
  sig2[,1] <- sig0^2
  for(ii in (1:nobs)+1) {
    sig2[,ii] <- omega + alpha * eps[,ii-1]^2 + beta * sig2[,ii-1]
    eps[,ii] <- sqrt(sig2[,ii]) * z[,ii-1]
  }
  # remove starting values
  sig2 <- sig2[,-1,drop=FALSE]
  eps <- eps[,-1,drop=FALSE]
  # format output
  ans <- .format_out(eps, sig2, z, eps0, sig0, nts, eps.only, init.out)
  ans
}

#--------------------------------------------------------------------------

#' Extract volatilities from GARCH observations.
#'
#' @param omega,alpha,beta GARCH parameters (see \code{\link{garch.sim}}).
#' @param eps Vector of GARCH observations \code{eps1, ..., epsN}.
#' @param eps20,sig20 Initial values, i.e., immediately prior to first observation.  Both default to \code{mean(eps^2)}.
#' @return Vector of square volatilities \code{sig21, ..., sig2N}.
#' @details The square-volatilities can be calculated using a built-in linear filter, which is much faster than using a for-loop.
#' @export
garch.sig2 <- function(omega, alpha, beta, eps, eps20, sig20) {
  N <- length(eps)
  eps2 <- eps^2
  mu <- mean(eps2)
  if(missing(eps20)) eps20 <- mu
  if(missing(sig20)) {
    sig20 <- mu
    ## sig20 <- garch.mom(eps, eta = alpha/omega, beta)
    ## sig20 <- sig20["omega"]/(1-sig20["alpha"]-sig20["beta"])
  }
  feps2 <- omega + alpha * c(eps20, eps2[-N]) # filtered eps^2
  as.numeric(filter(feps2, beta, "recursive", init = sig20)) # sig^2
}

#--------------------------------------------------------------------------

#' GARCH loglikelihood function.
#'
#' @param omega,alpha,beta GARCH parameters (scalars; see \code{\link{garch.sim}}).
#' @param eps Vector of GARCH observations \code{eps1, ..., epsN}.
#' @param eps20,sig20 Initial values, i.e., immediately before first observation.  For default values see \link{\code{garch.sig2}}.
#' @return The GARCH log-likelihood.
#' @details Validates parameters by checking that \code{all(sig2 > 0) == TRUE}.
#' @export
garch.loglik <- function(omega, alpha, beta, eps, eps20, sig20) {
  sig2 <- garch.sig2(omega, alpha, beta, eps, eps20, sig20) # sigma^2
  if(any(sig2 < 0)) return(-Inf) # prevent parameters giving negative variances
  sum(dnorm(eps, mean = 0, sd = sqrt(sig2), log = TRUE))
}

#--------------------------------------------------------------------------

#' GARCH profile loglikelihood.
#'
#' @details The reparametrized GARCH model is
#' \preformatted{
#' eps_t = omega * tsig_t * z_t
#' z_t ~iid N(0,1)
#' tsig_t^2 = 1 + eta * eps^2_t-1 + beta * tsig^2_t-1,
#' }
#' where \code{tsig_t = sig_t/omega} and \code{eta = alpha/omega}.  In this parametrization \code{omega} can be profiled out.
#' @param eta Parameter corresponding to \code{alpha/omega} of the original GARCH model.
#' @param beta Parameter of original GARCH model
#' @param eps Vector of GARCH observations \code{eps1, ..., epsN}.
#' @param tsig20 Initial value of \code{tsig^2}.
#' @details Let \code{mu = omega/(1-alpha-beta)} denote the unconditional mean of \code{sig20}.  Then with some algebra we arrive at \code{omega = mu(1-beta)/(1+mu*eta)}.  Substituting this for \code{omega} in \code{tmu = 1/(1-eta*omega-beta)}, the unconditional mean of \code{tsig20}, we have expressed it in terms of only \code{mu}, \code{beta}, and \code{eta}.  The default value of \code{tsig20} is obtained by substituting \code{mu = mean(eps^2)} in \code{tmu}.
#' @note Since Method-of-Moments initialization is still unstable, currently default value is \code{tsig20 = 1}.
#' @export
garch.profll <- function(eta, beta, eps, eps20, tsig20) {
  n <- length(eps)
  if(missing(tsig20)) {
    tsig20 <- 1
    ## tsig20 <- .init_tsig20(mean(eps^2), eta, beta)
    ## tsig20 <- garch.mom(eps, eta, beta)
    ## tsig20 <- 1/(1-tsig20["alpha"]-tsig20["beta"])
  }
  tsig2 <- garch.sig2(1, eta, beta, eps, eps20, tsig20) # tsig^2
  if(any(tsig2 < 0)) return(-Inf)
  ohat <- mean(eps^2/tsig2) # omega.hat(eta, beta)
  # profile loglikelihood
  -.5 * (n + n*log(ohat) + sum(log(tsig2)))
}

#--------------------------------------------------------------------------

#' Recover full parameter estimates from profile likelihood estimates.
#'
#' @param eta Parameter corresponding to \code{alpha/omega} of the original GARCH model.
#' @param beta Parameter of original GARCH parameter.
#' @param eps20,tsig20 Initial value and standardized square-volatility (see \code{\link{garch.profll}}).
#' @return A named vector of MLE \code{(omega, alpha, beta)}.
#' @export
garch.profmle <- function(eta, beta, eps, eps20, tsig20) {
  ## if(missing(tsig20)) tsig20 <- .init_tsig20(eps, eta, beta)
  if(missing(tsig20)) tsig20 <- 1
  tsig2 <- garch.sig2(1, eta, beta, eps, eps20, tsig20) # tsig^2
  ohat <- mean(eps^2/tsig2) # omega.hat(eta, beta)
  # transform back to original scale
  c(omega = as.numeric(ohat), alpha = as.numeric(eta*ohat),
    beta = as.numeric(beta))
}

#--------------------------------------------------------------------------

#' Method-of-moments GARCH parameter estimates.
#'
#' @param eps GARCH observations \code{eps1, ..., epsN}.
#' @param eta,beta Optional values of these parameters (see \code{\link{garch.profll}}), in which case only \code{omega} is estimated (see Details).
#' @return Vector of estimated GARCH parameters \code{(omega, alpha, beta)}.
#' @details Implements the MOM estimator of Kristensen and Linton (2006) generalized by Prono (2014), which can be used as starting points for \link{\code{garch.fit}}.
#' @note These MoM estimates are unstable, often returning inadmissible values, i.e., with \code{omega, alpha, beta < 0} and/or \code{alpha + beta > 1}.  Use at your own risk!
#' @references Kristensen, D. and Linton, O. "A closed-form estimator for the GARCH(1,1) model." \emph{Econometric Theory: Notes and Problems} 22 (2006): 323-337.
#' @references Prono, T. "Simple estimators for the GARCH(1,1) model." \emph{Technical Report:} Department of Finance and Real Estate, American University (2014). \url{https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1511720}.
#' @export
garch.mom <- function(eps, eta, beta) {
  n <- length(eps)
  eps2 <- eps*eps
  mu <- mean(eps2)
  if(!missing(eta) && !missing(beta)) {
    omega <- mu*(1-beta)/(1+mu*eta)
    alpha <- eta*omega
  } else {
    alpha <- abs(cor(eps2[2:n], eps[2:n-1]))
    rho <- cov(eps2[1:(n-1)],eps2[2:n])
    phi <- cov(eps2[1:(n-2)], eps2[3:n])/rho
    ## phi <- cor(eps2[1:(n-2)], eps2[3:n])
    #bb <- (phi^2 + 1 - 2*rho*phi)/(phi - rho)
    #beta <- (bb - sqrt(bb^2-4))/2
    #alpha <- phi - beta
    #phi <- as.numeric(coef(lm(eps2[2:n] ~ eps2[2:n-1] - 1)))
    #alpha <- mean((eps2[2:n]-mu)*eps[2:n-1])/mean(eps2*eps)
    beta <- phi-alpha
    omega <- mu * (1-phi)
  }
  c(omega = omega, alpha = alpha, beta = beta)
}

# initial value of tsig20
.init_tsig20 <- function(mu, eta, beta) {
  ohat <- mu*(1-beta)/(1+mu*eta)
  1/(1-eta*ohat-beta)
}

#--------------------------------------------------------------------------

#' Fit GARCH model.
#'
#' @param eps GARCH observations \code{eps1, ..., epsN}.
#' @param eps20,tsig20 Starting values.  For defaults see \link{\code{garch.profll}}.
#' @param eta0,beta0 Initial values for \code{optim}.  See details.
#' @param ... Further arguments passed to \code{optim}.  See details.
#' @return The MLE of the GARCH parameters \code{(omega, alpha, beta)}.
#' @details \code{optim} is given the negative profile log-likelihood, so that \code{...} can be completely used to specify control parameters.  Note that optimization is done on the \code{log(eta), log(beta)} scale and transformed back before output.
#' @export
garch.fit <- function(eps, eta0, beta0, eps20, tsig20, ...) {
  if(missing(eta0) | missing(beta0)) {
    theta0 <- garch.mom(eps)
  }
  if(missing(eta0)) eta0 <- theta0["alpha"]/theta0["omega"]
  if(missing(beta0)) beta0 <- theta0["beta"]
  if(missing(eps20)) eps20 <- mean(eps^2)
  ## if(missing(tsig20)) {
  ##   ## tsig20 <- .init_tsig20(mean(eps^2), eta, beta)
  ##   tsig20 <- garch.mom(eps, eta0, beta0)
  ##   tsig20 <- 1/(1-tsig20["alpha"]-tsig20["beta"])
  ## }
  if(missing(tsig20)) tsig20 <- 1
  ttheta0 <- c(eta0, beta0)
  gpfit <- optim(par = pmax(log(ttheta0), rep(-1,2)),
                 fn = function(ltheta) {
                   -garch.profll(eta = exp(ltheta[1]),
                                 beta = exp(ltheta[2]),
                                 eps = eps, eps20 = eps20,
                                 tsig20 = tsig20)
                 }, ...)
  if(gpfit$convergence != 0) {
    warning("optim did not converge.")
  }
  # convert back to original GARCH parameters
  theta.mle <- garch.profmle(eta = exp(gpfit$par[1]),
                             beta = exp(gpfit$par[2]),
                             eps = eps, eps20 = eps20, tsig20 = tsig20)
  theta.mle
}

#--- value-at-risk --------------------------------------------------------

#' Value-at-Risk calculation.
#'
#' @param nfwd Number of days to forecast.
#' @param nsim Number of paths to simulate.
#' @param tau Scalar or vector of VaR levels.
#' @param omega,alpha,beta GARCH parameters.
#' @param mu Optional mean parameter.
#' @param eps0,sig0 Initial values.
#' @param z Optional innovations to use.  If missing defaults to N(0,1).
#' @return the \code{tau}-level percent-return quantiles of the forecast distribution:  \code{p((S_nfwd - S_0)/S_0 | S_0)}
#' @details To obtain a single draw from this forecast distribution:
#' \enumerate{
#'   \item Generate \code{eps = (eps_1, ..., eps_nfwd)}
#'   \item Note that \code{S_nfwd/S_0 = exp(sum(eps))}, so percent-return is \code{(S_nfwd - S_0)/S_0 = exp(sum(eps)) - 1}.
#' }
#' @export
garch.VaR <- function(nfwd, nsim, tau = .05,
                      omega, alpha, beta,
                      eps0, sig0, z) {
  if(missing(eps0) || missing(sig0)) {
    stop("initial values must be provided for VaR calculation.")
  }
  if(nfwd == 1 && missing(z)) {
    # analytic calculation
    sig1 <- sqrt(omega + alpha * eps0^2 + beta * sig0^2)
    Yn <- qnorm(p = tau, sd = sig1) + mu # 1day fwd log-return
  } else {
    # generate time series for nfwd steps
    eps <- garch.sim(nobs = nfwd, nts = nsim, omega, alpha, beta,
                     eps0 = eps0, sig0 = sig0, z = z)
    Yn <- quantile(colSums(eps), probs = tau) # nfwd-day log-return
    ## Sn <- (exp(Yn) - 1) # nfwd-day regular return
    ## VaR <- quantile(Sn, probs = tau) # empirical quantiles
  }
  exp(Yn) - 1 # convert to percent-returns
}

## #' Calculate risk probability.
## #'
## #' @param nfwd Number of days to forecast.
## #' @param nsim Number of paths to simulate.
## #' @param gamma Scalar or vector of percent-loss levels.
## #' @param omega,alpha,beta GARCH parameters.
## #' @param mu Optional mean parameter.
## #' @param eps0,sig0 Initial values.
## #' @param S0 Initial asset value.
## #' @param z Optional innovations to use.  If missing defaults to N(0,1).
## garch.risk <- function(nfwd, nsim, gamma = .02,
##                        omega, alpha, beta, mu = 0,
##                        eps0, sig0, S0, z) {
##   if(missing(eps0) || missing(sig0)) {
##     stop("initial values must be provided for risk calculation.")
##   }
##   if(nfwd == 1 && missing(z)) {
##     # analytic calculation
##     sig1 <- sqrt(omega + alpha * eps0^2 + beta * sig0^2)
##     R1 <- pnorm(q = -gamma, sd = sig1) + mu
##     VaR <- (exp(Y1) - 1)*S0
##   } else {
##     # generate time series for nfwd steps
##     eps <- garch.sim(N = nfwd, nsim = nsim, omega, alpha, beta,
##                      eps0 = eps0, sig0 = sig0, z = z)
##     Yn <- colSums(eps + mu) # nfwd-day log-return
##     Sn <- (exp(Yn) - 1)*S0 # nfwd-day regular return
##     VaR <- quantile(Sn, probs = nu) # empirical quantiles
##   }
##   VaR
## }


#--------------------------------------------------------------------------

# formatting

# formats z innovations properly.
# gives error if z doesn't have right size
.format_z <- function(z, nobs, nts) {
  if(is.vector(z)) z <- as.matrix(z) # convert to matrix
  if(!is.matrix(z)) stop("z must be a vector or matrix.")
  z <- t(z) # assuming it's passed in as nobs x nts
  if(!all(dim(z) == c(nts, nobs))) {
    stop("z must be a vector of length nobs or matrix of dimension nobs x nts.")
  }
  z
}

# format output properly
.format_out <- function(eps, sig2, z, eps0, sig0, nts, eps.only, init.out) {
  if(nts == 1) {
    # convert back to scalars
    eps <- as.numeric(eps)
    sig2 <- as.numeric(sig2)
    z <- as.numeric(z)
  } else {
    # each column is a different series
    eps <- t(eps)
    sig2 <- t(sig2)
    z <- t(z)
  }
  # whether to return sigma and z
  if(eps.only) {
    ans <- eps
  } else {
    if(nts == 1) {
      ans <- cbind(eps = eps, sig = sqrt(sig2), z = z)
    } else {
      ans <- list(eps = eps, sig = sqrt(sig2), z = z)
    }
  }
  # whether to return initial values
  if(init.out) {
    init <- cbind(eps0 = eps0, sig0 = sig0)
    if(nts == 1) init <- init[1,]
    ans <- list(sim = ans, init = init)
  }
  ans
}
