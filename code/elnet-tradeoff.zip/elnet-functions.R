#--- plotting functions for the elastic net --------------------------------

#' points on the elastic net line
#' going clockwise, from beta1 = 0, beta2 = C.
#' so seems like penalty function rho_alpha(beta) <= C.
elnet.pts <- function(alpha, C = 1, npts = 100, debug = FALSE) {
  if(alpha == 1) {
    beta1 <- seq(0, C, len = npts)
    beta2 <- C-beta1
  } else {
    if(debug) browser()
    aa <- 1 - alpha
    bb <- alpha
    cc <- -C
    beta1 <- seq(0, .5 * (-bb + sqrt(bb^2 - 4*aa*cc))/aa, len = npts)
    cc <- (1-alpha) * beta1^2 + alpha * beta1 + cc
    beta2 <- .5 * (-bb + sqrt(abs(bb^2 - 4*aa*cc)))/aa
  }
  cbind(beta1 = c(beta1, rev(beta1), -beta1, -rev(beta1)),
        beta2 = c(beta2, -rev(beta2), -beta2, rev(beta2)))
}

# obtain points of an ellipse
ellipse.pts <- function (mu, V, alpha = 0.95, npts = 100) {
  tmp <- eigen(V)
  hlen <- sqrt(qchisq(alpha, df = 2) * tmp$val)
  theta <- atan2(tmp$vec[2, 1], tmp$vec[1, 1])
  t <- seq(0, 2 * pi, len = npts)
  x <- hlen[1] * cos(t)
  y <- hlen[2] * sin(t)
  alpha <- atan2(y, x)
  rad <- sqrt(x^2 + y^2)
  cbind(x = rad * cos(alpha + theta) + mu[1],
        y = rad * sin(alpha + theta) + mu[2])
}

# create two covariate of length 3 with
# mean(xi) = 1, var(xi) = 1, cor(x1,x2) = rho, and x1[3]=x2[3]=0
Xbasis <- function(rho) {
  x1 <- c(2/3,-1/3,-1/3)
  x2 <- c(-1/3,2/3,-1/3)
  x1 <- x1/sqrt(sum(x1^2))
  x2 <- x2 - sum(x1*x2)*x1
  x2 <- x2/sqrt(sum(x2^2))
  a <- rho/sqrt(1-rho^2)
  x2 <- a*x1 + x2
  x1 <- x1/sd(x1)
  x2 <- x2/sd(x2)
  cbind(x1 - x1[3], x2 - x2[3])
}

# parameter estimates for elastic net regression
elnet.fit <- function(bhat, XtX, alpha, lambda, debug = FALSE) {
  if(lambda == Inf) {
    # full penalty
    return(c(0,0))
  }
  l1 <- lambda*alpha
  l2 <- lambda*(1-alpha)
  yhat <- c(XtX %*% bhat)
  A <- XtX + diag(c(l2,l2))
  if(alpha == 0) {
    # ridge regression
    return(c(solve(A, yhat)))
  }
  # lasso/elnet regression
  PM <- cbind(c(1,1),c(1,-1),c(-1,1),c(-1,-1))
  # non-zero solutions
  b <- yhat - .5*l1 * PM
  mu <- solve(A, b)
  sgn <- sign(mu) == sign(PM)
  sgn <- sgn[1,] & sgn[2,]
  if(any(sgn)) return(mu[,which(sgn)[1]])
  if(debug) browser()
  # zero solutions (i.e., variable selection)
  A0 <- rep(diag(A), each = 2)
  b0 <- rep(yhat, each = 2) - .5*c(l1, -l1)
  mu0 <- b0/A0
  sgn0 <- sign(mu0) == c(1,-1)
  # no valid solutions
  if(sum(sgn0) == 0) return(c(0,0))
  # only one valid solution
  if(sum(sgn0) == 1) {
    if(which(sgn0) < 3) {
      mu <- c(mu0[sgn0], 0)
    } else {
      mu <- c(0, mu0[sgn0])
    }
    return(mu)
  }
  # two valid solutions
  Q0 <- - A0*mu0^2
  Q0 <- Q0[sgn0]
  mu0 <- mu0[sgn0]
  if(Q0[1] < Q0[2]) {
    mu <- c(mu0[1], 0)
  } else {
    mu <- c(0, mu0[2])
  }
  mu
}

# elastic net penalty
elnet.pen <- function(beta, alpha) {
  (1-alpha)*sum(beta^2) + alpha*sum(abs(beta))
}

# calculate the size of elnet lambda value for given constraint size C
elnet.lambda <- function(bhat, XtX, alpha, C, lambda.max = 10,
                         debug = FALSE) {
  if(debug) browser()
  uniroot(f = function(lambda) {
    Cl <- elnet.pen(beta = elnet.fit(bhat, XtX, alpha, lambda), alpha)
    Cl - C
  }, interval = c(0, lambda.max), extendInt = "yes")$root
}

#--- depreciated ---------------------------------------------------------------

## elnet.lambda <- function(bhat, XtX, alpha, C, lambda.max = 100,
##                          debug = FALSE) {
##   if(debug) browser()
##   # first try
##   lambda1 <- suppressWarnings(optimize(f = function(lambda) {
##     Cl <- elnet.pen(beta = elnet.fit(bhat, XtX, 0, lambda), 0)
##     max(abs(log(Cl) - log(C)), abs(C-Cl))
##   }, interval = c(1.2,lambda.max))$min)
##   # second try
##   llambda2 <- log(lambda1)
##   llambda2 <- llambda2 + c(-1,1) * 10 * abs(llambda2)
##   llambda2 <- suppressWarnings(optimize(f = function(llambda) {
##     lambda <- exp(llambda)
##     Cl <- elnet.pen(beta = elnet.fit(bhat, XtX, alpha, lambda), alpha)
##     abs(log(Cl) - log(C))
##   }, interval = llambda2)$min)
##   exp(llambda2)
## }
