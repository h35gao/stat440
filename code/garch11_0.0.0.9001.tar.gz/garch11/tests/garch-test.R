#--- test the garch functions ---------------------------------------------

source("garch-functions.R")

# generate some GARCH(1,1) data
omega <- 1e-6
alpha <- .1
beta <- .8
theta0 <- c(omega = omega, alpha = alpha, beta = beta)
N <- 1e3

# return both eps_t and sigma_t in order to check sigma_t^2 filter
sig0 <- sqrt(omega/(1-alpha-beta)) # default starting values
eps0 <- rnorm(1, mean = 0, sd = sig0)
Eps <- garch.sim(N = N, omega = omega, alpha = alpha, beta = beta,
                 eps.only = FALSE)

# filter for sigma_t^2
sig2 <- garch.sig2(omega = omega, alpha = alpha, beta = beta,
                   eps = Eps[,1],
                   eps20 = eps0^2, sig20 = sig0^2)

range((sig2 - Eps[,"sig"]^2)/Eps[,"sig"]^2)

#--- method-of-moments estimate --------------------------------------------

theta.mom <- garch.mom(eps)

#--- likelihood and profile likelihood calculations -----------------------

source("mle-check.R")

eps <- Eps[,"eps"]

# loglikelihood to match profile likelihood
loglik.full <- function(theta) {
  #if(any(theta <= 0)) return(-Inf)
  #if(1-theta[2]-theta[3] <= 0) return(-Inf)
  garch.loglik(omega = theta[1], alpha = theta[2], beta = theta[3],
               eps = eps,
               sig20 = theta[1])
}


# now profile likelihood
# lttheta = (log(eta), log(beta))
loglik.prof <- function(lttheta) {
  garch.profll(exp(lttheta[1]), exp(lttheta[2]), eps)
}

# quick test
garch.profll(eta = alpha/omega, beta = beta, eps = eps)

theta.mle <- garch.fit(eps = eps)

lttheta.mle <- log(c(eta = theta.mle[2]/theta.mle[1],
                     beta = theta.mle[3]))

## ttheta0 <- c(1, 1e-6) #c(alpha/omega, beta)
## gpfit <- optim(par = log(ttheta0), fn = loglik.prof,
##                control = list(fnscale = -1))#,
##                  #parscale = c(1, 1e-5)))


## # check if profile likelihood has attained max
## mle.check(loglik = loglik.prof,
##           theta.mle = lttheta.mle,
##           theta.names = expression(log(eta), log(beta)))

## profile likelihood estimate
## theta.mle <- garch.profmle(eta = gpfit$par[1],
##                            beta = gpfit$par[2],
##                            eps = eps)

# check full mle
tnames <- expression(omega, alpha, beta)
mle.check(loglik = loglik.full, refit = TRUE,
          #theta.rng = cbind(c(1.5e-6,2e-6), c(.08,.1), c(.6,.8)),
          theta.mle = theta.mle, theta.names = tnames)


#--- multiple series garch simulation -------------------------------------

source("garch-functions.R")

omega <- 1e-6
alpha <- .1
beta <- .8
theta0 <- c(omega, alpha, beta)

# univariate simulation
N <- 10
nsim <- 5
tau <- omega/(1-alpha-beta) # stationary variance
eps0 <- rnorm(nsim, sd = sqrt(tau))
z <- matrix(rnorm(N*nsim), N, nsim)

# univariate
eps1 <- sapply(1:nsim, function(ii) {
  garch.sim(N = N+1, omega = omega, alpha = alpha, beta = beta,
            eps0 = eps0[ii], z = z[,ii], debug = FALSE)
})

# multivariate
eps2 <- garch.sim2(N = N, nsim = nsim,
                   omega = omega, alpha = alpha, beta = beta,
                   eps0 = eps0, z = z, eps.only = FALSE, init.out = TRUE)

range(eps1[-1,]-eps2)



#--- value-at-risk --------------------------------------------------------

omega <- 1e-6
alpha <- .1
beta <- .8
tau <- omega/(1-alpha-beta) # stationary variance
sig0 <- sqrt(tau)
eps0 <- -4*sig0

# ok 1-step VaR
VaR.alpha <- c(.01, .05, .1)
gVaR1 <- qnorm(p = VaR.alpha, mean = 0,
              sd = sqrt(omega + alpha*eps0^2 + beta*sig0^2))

gVaR2 <- garch.VaR(nfwd = 1, VaR = VaR.alpha,
                   omega = omega, alpha = alpha, beta = beta,
                   eps0 = eps0, sig0 = sig0, nsim = 1e6)

rbind(det = gVaR1,
      sim = gVaR2)

# two steps

# ok forward simulation
system.time({
eps <- garch.sim(N = 2, nsim = 1e6, omega = omega, alpha = alpha,
                 beta = beta, eps0 = eps0, sig0 = sig0)
})

npts <- 200
eps.seq <- range(eps[2,])
eps.seq <- seq(eps.seq[1], eps.seq[2], len = npts)
eps.ll2 <- apply(as.matrix(expand.grid(eps.seq, eps.seq)),
                 MARGIN = 1,
                 function(ee) {
                   garch.loglik(omega = omega, alpha = alpha, beta = beta,
                                eps20 = eps0^2, sig20 = sig0^2,
                                eps = ee)
                 })

eps.dens <- matrix(exp(eps.ll2 - max(eps.ll2)), npts, npts)
eps.dens <- colSums(eps.dens)
eps.dens <- eps.dens/sum(eps.dens)/diff(eps.seq[1:2])

plot(density(eps[2,]))
lines(eps.seq, eps.dens, col = "red")

#--- rugarch package ------------------------------------------------------

require(rugarch)

spec <- ugarchspec(mean.model = list(armaOrder = c(0,0)),
                   fixed.pars = list(omega = 1e-6, alpha1 = .1, beta1 = .8, mu = 0))

sim <- ugarchpath(spec = spec, n.sim=10, n.start=1, m.sim=1,
                  startMethod="unconditional")
sapply(sim@path, head)

#--- scratch ---------------------------------------------------------------

# full likelihood
loglik.full <- function(theta) {
  if(any(theta <= 0)) return(-Inf)
  if(1-theta[2]-theta[3] <= 0) return(-Inf)
  garch.loglik(theta[1], theta[2], theta[3], eps)
}

gfit <- optim(par = theta0, fn = loglik.full,
              control = list(fnscale = -1))

theta.mle <- gfit$par
tnames <- expression(omega, alpha, beta)

mle.check(loglik = function(theta) loglik.full(theta),
          theta.mle = gfit$par, theta.names = tnames)
