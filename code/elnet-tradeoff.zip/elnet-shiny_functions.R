#--- functions to plot the elastic net tradeoff in shiny -------------------

source("elnet-functions.R")

# TODO: make these functions not refer to globals

# data function
data.fun <- function(Bhat, XtX, C, alpha, npts = 100) {
  Alpha <- c(lasso = 1, elnet = alpha, ridge = 0)
  V <- solve(XtX)
  V <- V/max(diag(V))*C
  lapply(1:nrow(Bhat), function(ii) {
    bhat <- Bhat[ii,] # OLS estimate
    # Penalized estimates
    Lambda <- sapply(Alpha, function(alpha) {
      elnet.lambda(bhat, XtX, alpha, C = alpha*C + (1-alpha)*C^2)
    }) # amount of penalty
    Btilde <- sapply(c(lasso = 1, elnet = 2, ridge = 3),
                     function(ii) {
                       elnet.fit(bhat, XtX, Alpha[ii], Lambda[ii])
                     }) # estimate of each
    # loglikelihood contour intersecting the points
    Loglik <- array(NA, dim = c(npts, 2, 3),
                    dimnames = list(NULL, c("x", "y"),
                      c("lasso", "elnet", "ridge")))
    for(iest in 1:3) {
      qchi <- crossprod(Btilde[,iest]-bhat, solve(V, (Btilde[,iest]-bhat)))[1]
      Loglik[,,iest] <- ellipse.pts(mu = bhat, V = V, npts = npts,
                                    alpha = pchisq(qchi, df = 2))
    }
    # output
    list(bhat = bhat, Btilde = Btilde, Loglik = Loglik, Lambda = Lambda)
  })
}

# plot function
plot.fun <- function(pdata, Bhat, Pen, beta, xlim, ylim, main, lwd = 2) {
  for(iest in 1:3) {
    plot(0, type = "n",
         xlim = xlim, ylim = ylim, asp = 1,
         main = main[iest], cex.lab = 2, cex.main = 2,
         xlab = expression(beta[1]), ylab = expression(beta[2]))
    abline(v = 0, lty = 2)
    abline(h = 0, lty = 2)
    # beta_hat contour
    lines(Bhat, col = "blue", lwd = lwd)
    # beta_tilde contour
    lines(pdata$Loglik[,,iest], col = "black", lwd = lwd)
    # penalty contour
    lines(Pen[[iest]], col = "red", lwd = lwd)
    # points
    points(t(beta), col = "blue", pch = 16, cex = 2) # beta0
    points(t(pdata$bhat), pch = 16, cex = 2, col = "black") # beta_hat
    points(t(pdata$Btilde[,iest]),
           col = "red", pch = 16, cex = 2) # beta_tilde
  }
}
