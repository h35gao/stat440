#' Inference and forecasting for the GARCH(1,1) model.
#'
#' @details The GARCH(1,1) model is defined as
#' \preformatted{
#' eps_t = sig_t * z_t
#' sig^2_t^2 = omega + alpha * eps^2_t-1 + beta * sig^2_t-1,
#' }
#' where \code{z_t} are iid innovations with mean 0 and variance 1.  The fitting algorithm assumes these are normal, but the simulation algorithm allows them to be specified arbitrarily.
#' @name garch11
#' @docType package
#' @import stats
NULL
